#Cria variável do tipo inteiro
x = 1
#Cria variável do tipo float
y = 3.13
#Cria variável do tipo string
m = "Python"
m = 'Python'
#Cria variável do tipo lógica
w = True  
y = False
print(y)
#calculadora
x = 10
y = 20
z = 100
w = (x + y) * z / 100
print(w)
#exibir texto no console
print("Este texto será impresso no console")
print(x)
print("Texto e duas variáveis: ", x ,", ", z)

#verificar tipo
print(type(x))
print(type(m))

#entrada de dados
print("Informe o valor: ")
i = input()
#mostra tipo string
print(type(i))

#entrada de valor com msg separada e junto
print("Informe o valor: ")
i = input()
# ou
i = input("Informe o valor: ")

#conversão de valores
#para inteiro
var = input("Informe o valor: ")
print(type(var))
var = int(var)
print(type(var))

#para float
var = input("Informe o valor: ")
print(type(var))
var = float(var)
print(type(var))

# Este texto é um comentário
X = 10  # a partir daqui é um comentário

''' Aqui começa um comentário
Aqui ele continua
e aqui ele termina '''




