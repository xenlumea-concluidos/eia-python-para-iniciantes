import statistics 
z = [10,20,30,40]
x = statistics.mean(z)
y = statistics.median(z)
print(x)
print(y)

import statistics  as est
z = [10,20,30,40]
x = est.mean(z)
y = est.median(z)
print(x)
print(y)


from statistics import mean, median
z = [10,20,30,40]
x = mean(z)
y = median(z)
print(x)
print(y)


from statistics import *
z = [10,20,30,40]
x = mean(z)
y = median(z)
print(x)
print(y)
