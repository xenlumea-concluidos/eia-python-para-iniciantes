
nota = 7
if nota >= 7:
	print("Aprovado")
else:
	print("Reprovado")

#só mudar o valor da variável
nota = 5
if nota >= 7:
	print("Aprovado")
else:
	print("Reprovado")


#so adicionar as partes com elif
#testar com 3, 5  e 7

if nota <= 4:
	print("Reprovado")
elif nota > 4 and nota <=6:
	print("Exame")
else:
	print("Aprovado")
